$(document).ready(function () {
var c = 0;
var h = 0;
$("#score").html('Score : '+c+'<br> High Score : '+h);
$("#yeti").mousedown(function () {
alert("Yaaaarrrr!");
} );
RandomImage();

$(".Peng").on('click', function () {  
 c = c + 1;
var num = $(this).attr('id');
var Char = num.substr(num.length - 1);
if ($(this).hasClass("Peng yeti"))
{  
$(this).css('background-image', 'url(images/yeti.png)');
alert("Yaaaarrrr ! Its Yetiiit");
h = c;
$("#score").html('Score: '+c+'<br> High Score : '+ h);
alert("Game Over. Want to Play Next Game Click Ok.");
location.reload();
}
else
{
$(this).css('background-image', 'url(images/penguin_' + Char + '.png)'); 
var audio=new Audio();
audio.src="button-2.mp3";
audio.play();  
$("#score").html('Score : '+c+'<br> High Score : '+h);
    
}
if(c==12)
{            
alert("congratulation you have won the game");
h = c;
var audio=new Audio();
audio.src="applause-01.mp3";
audio.play(); 
}
});
function RandomImage() {
 var n = Math.floor(Math.random() * 13);
$("#penguin" + n).addClass('yeti');
$("#penguin" + n).attr('id', 'yeti');   
}
});